<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('HOST_NAME', 'localhost');
define('BASE_URL', '/projects/ca_online');
define('DB_NAME', 'db_ca_online');
define('DB_USER', 'root');
define('DB_PSWD', '');

// Définir la zone horaire locale
date_default_timezone_set('Africa/Abidjan');