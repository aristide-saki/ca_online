<?php
session_start();

include 'includes/__init__.php';
include 'includes/autoload.php';
include 'app/models/Format.php';
include 'routes/web.php';